export class Expense {
    _id : string;
    name : String;
    details : String;
    amount : Number;
    date : Date = new Date();
}

