import { CustomerAutomobile } from './customer-automobile';

describe('CustomerAutomobile', () => {
  it('should create an instance', () => {
    expect(new CustomerAutomobile()).toBeTruthy();
  });
});
