import {Submodels} from './submodels';

export class Brands {
    _id : string;
    name : string;
    submodels : Submodels[] = [];
}


