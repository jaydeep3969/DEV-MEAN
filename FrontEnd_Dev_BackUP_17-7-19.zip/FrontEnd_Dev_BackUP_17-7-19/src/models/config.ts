export class Config {
    _id : string;
    label : String;
    value : any;
}
