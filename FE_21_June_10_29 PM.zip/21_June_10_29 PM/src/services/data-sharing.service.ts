import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataSharingService {

  bill_id : string = null;

  constructor() { }

  getBillId(cb) {
    setTimeout(() => {
      console.log("--Get Bill Id--"+this.bill_id);
      cb(this.bill_id);      
    }, 1000);
  }

  setBillId(id:string,cb){
    setTimeout(() => {
      console.log("--Set Bill Id--");
      this.bill_id = id;
      console.log(this.bill_id);
      cb();
    }, 1000);
  }
}
