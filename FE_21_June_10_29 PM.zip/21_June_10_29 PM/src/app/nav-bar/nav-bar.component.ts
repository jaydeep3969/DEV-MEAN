import { Component, OnInit } from '@angular/core';
import {MenuItem} from 'primeng/api';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})
export class NavBarComponent implements OnInit {

  items: MenuItem[];
  activeItem : string = "new_bill";

  constructor() { }

  ngOnInit() {
    this.items = [
            {label: 'Dashboard', icon: 'fa fa-fw fa-bar-chart', command : (event) => {
              this.activeItem = "dashboard";
            }},
            {label: 'Items', icon: 'pi pi-list', command : (event) => {
              this.activeItem = "items";
            }},
            {label: 'Customers', icon: 'fa fa-fw fa-users', command : (event) => {
              this.activeItem = "customers";
            }},
            {label: 'New Bill', icon: 'fa fa-fw fa-shopping-cart',command : (event) => {
              this.activeItem = "new_bill";
            }}
        ];

    this.activeItem = "customers";
  }

}
