import { Component, OnInit} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import { ItemsElectronic, BillElectronics } from 'src/models/bills/bill-electronics';
import { CustomerElectronic } from 'src/models/customers/customer-electronic';
import { BillsManagementService } from 'src/services/bills-management.service';

@Component({
  selector: 'app-preview-electronic-bill',
  templateUrl: './preview-electronic-bill.component.html',
  styleUrls: ['./preview-electronic-bill.component.css']
})
export class PreviewElectronicBillComponent implements OnInit {

  bill_id : string;
  items : ItemsElectronic[];
  bill : BillElectronics;
  total_qty : number = 0;
  receiver : CustomerElectronic;
  cols : any[];
  bill_loaded : boolean = false;

  constructor(private billsManagementService : BillsManagementService,
              private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.bill_id = this.activatedRoute.snapshot.paramMap.get('id');
    this.getBill();

    this.cols =[
      {field: 'product_name', header: 'Product Name', width : '45%', align : null},
      {field: 'quantity', header: 'Quantity', width : '10%', align : null },
      {field: 'rate', header: 'Rate', width : '20%', align : 'right'},
      {field: 'amount', header: 'Amount Rs', width : '20%', align : 'right'}
    ];
  }

  getBill(){
    this.billsManagementService.getBill('bill_electronic', this.bill_id)
      .subscribe(bill =>{
        this.bill = bill as BillElectronics;
        this.items = this.bill.items;
        this.receiver = this.bill.receiver;
        this.calculateTotal();
      })
  }


  calculateTotal(){
    for(let i=0; i < this.items.length; i++)
    {
      this.total_qty += this.items[i].quantity;
      this.bill_loaded = true;
    }
  }
}


