export class Clothes {
    _id : string;
    name : string;
    quantity : number = 0;
    pp : number = 0.0;  //purchase price
    sp : number = 0.0; //selling price
}
