export class Address {
    streetline : String;
    area : String;
    city : String = "Surat";
    state : String = "Gujarat";
}
