import { BillClothes } from './bill-clothes';

describe('BillClothes', () => {
  it('should create an instance', () => {
    expect(new BillClothes()).toBeTruthy();
  });
});
