module.exports = (app) => {
    const customer_cloth = require('../../controllers/customers/customer_clothes.controller') ;

    // Create a new Bill(Cloth)
    app.post('/api/customer_cloth', customer_cloth.create);

    // Retrieve all Bills(Cloth)
    app.get('/api/customer_cloth', customer_cloth.findAll);

    // Retrieve a single Bill(Cloth) with id
    app.get('/api/customer_cloth/:customerId', customer_cloth.findOne);

    // Update a Bill(Cloth) with id
    app.put('/api/customer_cloth/:customerId', customer_cloth.update);

    // Delete a Bill(Cloth) with id
    app.delete('/api/customer_cloth/:customerId', customer_cloth.delete);
}