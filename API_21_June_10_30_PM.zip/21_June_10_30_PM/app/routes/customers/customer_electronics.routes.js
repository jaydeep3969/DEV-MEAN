module.exports = (app) => {
    const customer_electronic = require('../../controllers/customers/customer_electronics.colntroller') ;

    // Create a new Bill(Cloth)
    app.post('/api/customer_electronic', customer_electronic.create);

    // Retrieve all Bills(Cloth)
    app.get('/api/customer_electronic', customer_electronic.findAll);

    // Retrieve a single Bill(Cloth) with id
    app.get('/api/customer_electronic/:customerId', customer_electronic.findOne);

    // Update a Bill(Cloth) with id
    app.put('/api/customer_electronic/:customerId', customer_electronic.update);

    // Delete a Bill(Cloth) with id
    app.delete('/api/customer_electronic/:customerId', customer_electronic.delete);
}