let mongoose = require('mongoose');

let electronicSchema = new mongoose.Schema({
    sr_no_ele : Number,
    name : String,
    quantity : Number,
    pp : Number
})

module.exports = mongoose.model('Electronic', electronicSchema)