let mongoose = require('mongoose');

let clotheSchema = new mongoose.Schema({
    name : String,
    quantity : Number,
    pp : Number
})

module.exports = mongoose.model('Clothe', clotheSchema)