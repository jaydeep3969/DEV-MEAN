let mongoose = require('mongoose');

let automobileCustomerSchema = new mongoose.Schema({
    name : String,
    contact : Number
})

module.exports = mongoose.model('CustomerAutomobile', automobileCustomerSchema)