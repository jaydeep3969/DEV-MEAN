import { Deposite } from './deposite';

describe('Deposite', () => {
  it('should create an instance', () => {
    expect(new Deposite()).toBeTruthy();
  });
});
