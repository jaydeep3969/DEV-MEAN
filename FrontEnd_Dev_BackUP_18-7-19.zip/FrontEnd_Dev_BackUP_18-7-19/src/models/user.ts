export class User {
    _id : string;
    username : string;
    name : string;
    password : string;
}

