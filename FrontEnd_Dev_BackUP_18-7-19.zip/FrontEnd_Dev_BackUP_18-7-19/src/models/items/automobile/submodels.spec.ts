import { Submodels } from './submodels';

describe('Submodels', () => {
  it('should create an instance', () => {
    expect(new Submodels()).toBeTruthy();
  });
});
