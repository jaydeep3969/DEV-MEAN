import { BillElectronics } from './bill-electronics';

describe('BillElectronics', () => {
  it('should create an instance', () => {
    expect(new BillElectronics()).toBeTruthy();
  });
});
