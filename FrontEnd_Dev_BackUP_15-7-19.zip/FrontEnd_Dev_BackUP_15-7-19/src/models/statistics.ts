export class Statistics {
    _id : string;
    item_type : string;
    value : [ {
                year : Number;
                profit : Number;
                sell : Number;
                purchase : Number;
                expense : Number;
                value : [
                    {
                        month : Number;
                        profit : Number;
                        sell : Number;
                        purchase : Number;
                        expense : Number;
                        value : [
                            {
                                day : Number;
                                profit : Number;
                                sell : Number;
                                purchase : Number;
                                expense : Number;
                            }
                        ]
                    }
                ]
             }
        ]
}
