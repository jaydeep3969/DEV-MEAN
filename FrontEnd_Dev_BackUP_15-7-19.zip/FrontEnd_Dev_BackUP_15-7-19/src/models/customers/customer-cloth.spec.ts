import { CustomerCloth } from './customer-cloth';

describe('CustomerCloth', () => {
  it('should create an instance', () => {
    expect(new CustomerCloth()).toBeTruthy();
  });
});
