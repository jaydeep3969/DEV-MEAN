import { CustomerElectronic } from './customer-electronic';

describe('CustomerElectronic', () => {
  it('should create an instance', () => {
    expect(new CustomerElectronic()).toBeTruthy();
  });
});
