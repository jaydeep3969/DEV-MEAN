import { Electronics } from './electronics';

describe('Electronics', () => {
  it('should create an instance', () => {
    expect(new Electronics()).toBeTruthy();
  });
});
