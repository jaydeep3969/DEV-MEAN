import { Statistics } from './statistics';

describe('Statistics', () => {
  it('should create an instance', () => {
    expect(new Statistics()).toBeTruthy();
  });
});
