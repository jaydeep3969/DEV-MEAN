export class Deposite {
    name : string;
    amount : number;
    date : Date = new Date();
}
