import { Component, OnInit } from '@angular/core';
import {MenuItem} from 'primeng/api';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})
export class NavBarComponent implements OnInit {

  items: MenuItem[];
  activeItem : string = "dashboard";
  activeMenu : String = "stats";
  header : string = "Statistics";

  constructor() { }

  ngOnInit() {
    this.items = [
            {label: 'Dashboard', icon: 'fa fa-fw fa-bar-chart', command : (event) => {
              this.activeItem = "dashboard";
              this.openNav();
            }},
            {label: 'Items', icon: 'pi pi-list', command : (event) => {
              this.activeItem = "items";
            }},
            {label: 'Customers', icon: 'fa fa-fw fa-users', command : (event) => {
              this.activeItem = "customers";
            }},
            {label: 'Bills', icon: 'fa fa-fw fa-copy', command : (event) => {
              this.activeItem = "bills";
            }},
            {label: 'New Bill', icon: 'fa fa-fw fa-shopping-cart',command : (event) => {
              this.activeItem = "new_bill";
            }}
        ];
  }

  setFields() {
    if(this.activeMenu == 'collection')
    {
      this.header = "Collections";
    }
    else if(this.activeMenu == 'expense')
    {
      this.header = "Expenses";
    }
    else if(this.activeMenu == 'config')
    {
      this.header = "Configurations";
    }
    else if(this.activeMenu == 'stats')
    {
      this.header = "Statistics";
    }
  }

  openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
    document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
  }

  clickNav(selected_menu : string) {
    this.activeMenu = selected_menu;
    this.closeNav();
    this.setFields();
    // if(selected_menu == 'collection')
    // {

    // }
    // else if(selected_menu == 'expense')
    // {

    // }
    // else if(selected_menu == 'config')
    // {

    // }
    // else if(selected_menu == 'stats')
    // {

    // }
  }

  closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft = "0";
    document.body.style.backgroundColor = "white";
  }

}
