import { Component, OnInit } from '@angular/core';
import { StatisticsManagementService } from 'src/services/statistics-management.service';
import { Statistics } from 'src/models/statistics';

@Component({
  selector: 'app-statistics',
  templateUrl: './statistics.component.html',
  styleUrls: ['./statistics.component.css']
})
export class StatisticsComponent implements OnInit {

  data : any;
  stats : Statistics[];
  
  labels = [];
  purchase_data  = [];
  sell_data  = [];
  profit_data  = [];
  expense_data  = [];

  years = [];

  months = ['January', 'February', 'March', 'April', 'May', 'June', 'July','August','Sepetember','November','December'];

  days = [];
  
  constructor(private statsManagementService : StatisticsManagementService) { }

  ngOnInit() {
    this.load_stats();
    // this.set_data();
  }

  load_stats() {
    this.statsManagementService.getStats()
      .subscribe(stats => {
          this.stats = stats;
          this.get_years();
          
          this.get_day_data(2018,5,'clothes');
          this.set_data();
        });
  }

  get_years() {
    this.years = [];
    var item = this.stats.find(i => i.item_type == 'clothes');
    item.value.forEach(year => { 
      this.years.push(year.year);
    })
  }

  get_year_data(item_type : string){
    this.labels = this.years;

    var item = this.stats.find(i => i.item_type == item_type);

    item.value.forEach(year => {
      this.purchase_data.push(year.purchase);
      this.sell_data.push(year.sell);
      this.profit_data.push(year.profit);
      this.expense_data.push(year.expense);
    });
  }

  get_month_data(year_no : Number, item_type : string) {
    this.labels = this.months;
    var item = this.stats.find(i => i.item_type == item_type);
    var year = item.value.find(y => y.year == year_no);

    year.value.forEach(month => {
      this.purchase_data.push(month.purchase);
      this.sell_data.push(month.sell);
      this.profit_data.push(month.profit);
      this.expense_data.push(month.expense);
    });
  }

  get_day_data(year_no : Number, month_no : Number, item_type : string){
    this.days = [];
    var item = this.stats.find(i => i.item_type == item_type);
    var year = item.value.find(y => y.year == year_no);
    var month = year.value.find(m => m.month == month_no);

    month.value.forEach(day => {
      this.days.push(day.day);
      this.purchase_data.push(day.purchase);
      this.sell_data.push(day.sell);
      this.profit_data.push(day.profit);
      this.expense_data.push(day.expense);
    });

    this.labels = this.days;
  }

  set_data() {
    this.data = 
    {
      labels: this.labels,
      datasets: [
        {
            label: 'Purchase',
            backgroundColor: '#42A5F5',
            borderColor: '#1E88E5',
            data: this.purchase_data
        },
        {
            label: 'Sell',
            backgroundColor: '#800080',
            borderColor: '#8B008B',
            data: this.sell_data
        },
        {
          label: 'Profit',
          backgroundColor: '#9CCC65',
          borderColor: '#7CB342',
          data: this.profit_data
        },
        {
            label: 'Expense',
            backgroundColor: '#FF0000',
            borderColor: '#FF4500',
            data: this.expense_data
        }
      ]
    }
  }


}
