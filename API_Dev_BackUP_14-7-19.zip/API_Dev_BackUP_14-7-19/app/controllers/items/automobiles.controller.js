const Automobile = require('../../../models/items/automobiles.model')

// Create and Save a new brand
exports.create = (req, res) => {

    //Create a brand
    const brand = new Automobile({
        name : req.body.name,
        submodels : req.body.submodels
    })

    //Save Automobile in DB
    brand.save()
        .then( data => {
            console.log("Brand successfully saved !");
            res.send(data);
        })
        .catch(err => {
            res.status(500).send({
                message : err.message || "Some error occurred while creating the brand-item"
            })
        });
};



// Retrieve and return all users from the database.
exports.findAll = (req, res) => {
    Automobile.find()
        .then( automobiles => {
            console.log("Automobiles successfully retrieved !");
            res.send(automobiles);
        })
        .catch(err => {
            res.status(500).send({
                message : err.message || "Some error occurred while retrieving automobiles"
            })            
        });
};



// Find a single automobile with a userId
exports.findOne = (req, res) => {

    Automobile.findById(req.params.automobileId)
        .then( automobile => {
            if(!automobile)
            {
                return res.status(404).send({
                    message : "Automobile not found !"
                })
            }

            console.log("Automobile with id successfully retrieved !");
            res.send(automobile);
        })
        .catch(err => {
            if(err.kind === 'ObjectId'){
                return res.status(404).send({
                    message : "Automobile not found !"
                });
            }
            
            return res.status(500).send({
                message : err.message || "Some error occured while retrieving automobile with id"
            });
            
        });
};



// Update a automobile identified by the userId in the request
exports.update = (req, res) => {

    //find user and update it with the request body
    Automobile.findByIdAndUpdate( req.params.automobileId, {
        name : req.body.name,
        submodels : req.body.submodels
    }, {new : true})
        .then(automobile => {
            if(!automobile) {
                return res.status(404).send({
                    message : "Automobile not found with this id !"
                });
            }

            console.log("Automobile successfully updated !");
            res.send(automobile);
        })
        .catch(err => {
            if(err.kind === 'ObjectId'){
                return res.status(404).send({
                    message : "Automobile not found with this id !"
                });
            }

            res.status(500).send({
                message : err.message || "Some error occurred while updating the automobile !"
            });
        })
};



// Delete a automobile with the specified userId in the request
exports.delete = (req, res) => {
    Automobile.findByIdAndRemove(req.params.automobileId)
        .then(automobile => {
            if(!automobile) {
                return res.status(404).send({
                    message : "Automobile not found with this id !"
                });
            }

            console.log("Automobile successfully deleted !");
            res.send({
                message : "Automobile successfully deleted !"
            });
        })
        .catch(err => {
            if(err.kind === 'ObjectId' || err.name === 'NotFound'){
                return res.status(404).send({
                    message : "Automobile not found with this id !"
                })
            }

            res.status(500).send({
                message : "Could not delete the automobile with this id !"
            });     
        })
};

//find a model by name
exports.findOneByName = (req, res) => {
    Automobile.findOne({ 'name' : req.params.brandName })
        .then( brand => {
            if(!brand)
            {
                return res.status(404).send({
                    message : "Brand not found !"
                })
            }

            console.log("Brand with name successfully retrieved !");
            
            brand.submodels.forEach(model => {
                if(model.name == req.params.modelName)
                    res.send(model);
            });
        })
        .catch(err => {
            if(err.kind === 'ObjectId'){
                return res.status(404).send({
                    message : "Brand not found !"
                });
            }
            
            return res.status(500).send({
                message : err.message || "Some error occured while retrieving brand with name"
            });
            
        });
};