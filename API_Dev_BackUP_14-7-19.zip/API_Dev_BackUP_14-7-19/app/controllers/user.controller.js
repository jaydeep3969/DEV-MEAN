const User = require('../../models/user.model');
const Stats = require('../../models/stats.model');

// Create and Save a new User
exports.create = (req, res) => {

    // Create a User
    const user = new User({
        username : req.body.username,
        contact : req.body.contact,
        password : req.body.password
    })

    //Save User in DB
    user.save()
        .then( data => {
            console.log("User successfully saved !");
            res.send(data);
        })
        .catch(err => {
            res.status(500).send({
                message : err.message || "Some error occurred while creating the user"
            })
        });
};

// Retrieve and return all Users from the database.
exports.findAll = (req, res) => {
    User.find()
        .then( users => {
            console.log("Users successfully retrieved !");
            res.send(users);
        })
        .catch(err => {
            res.status(500).send({
                message : err.message || "Some error occurred while retrieving Users"
            })            
        });
};

// Find a single user with a userId
exports.findOne = (req, res) => {

    User.findById(req.params.userId)
        .then( user => {
            if(!user)
            {
                return res.status(404).send({
                    message : "User not found !"
                })
            }

            console.log("User with id successfully retrieved !");
            res.send(user);
        })
        .catch(err => {
            if(err.kind === 'ObjectId'){
                return res.status(404).send({
                    message : "User not found !"
                });
            }
            
            return res.status(500).send({
                message : err.message || "Some error occured while retrieving user with id"
            });
            
        });
};

// Verify User
exports.verify =  (req, res) => {
    User.findOne({ username : req.body.username, password : req.body.password})
        .then(user => {
            if(!user)
                res.send({message : -1});

            let today = new Date();
            let day  = today.getDay();
            let month  = today.getMonth();
            let year  = today.getFullYear();

            console.log(day + '/' + month + '/' + year);
            console.log(today);
            Stats.findOne({ item_type : "clothes"})
                .then(item_level => {
                    //var item = await stats.find(item => item.item_type == "clothes");//findOne({ item_type : 'clothes'})
                    var year_level =  item_level.value.find(y => y.year == year);
                    var month_level =  year_level.value.find(m => m.month == month);
                    var day_level =  month_level.value.find(d => d.day == day);

                    if(day_level)
                    {
                        console.log("-------------Mil Gaya !");
                        console.log(day_level.profit);
                        console.log(day_level.sell);
                        console.log(day_level.purchase);
                        console.log(day_level.expense);
                    }
                    else 
                        console.log("-------------Nahi Yaar!")
                        // .then(item_level => {
                        //     item_level.value.findOne({ year : 2019})
                        //         .then( year_level => {
                        //             year_level.value.findOne({month : 7})
                        //                 .then(month_level => {
                        //                     month_level.value.findOne({ day : 15})
                        //                         .then(day_level => {
                        //                             console.log("----------------------");
                        //                             if(day_level)
                        //                                 console.log("Mil Gaya !")
                        //                             else 
                        //                                 console.log("Abe Yaar!");
                        //                             console.log("----------------------");
                        //                         })
                        //                 })
                        //         })
                        // })
                })
            res.send({message : 1});
        })
        .catch(err => {
            if(err.kind === 'ObjectId'){
                return res.status(404).send({
                    message : "User not found !"
                });
            }
            
            return res.status(500).send({
                message : err.message || "Some error occured while retrieving user with id"
            });
            
        });
}

// Update a user identified by the userId in the request
exports.update = (req, res) => {

    //find user and update it with the request body
    User.findByIdAndUpdate( req.params.userId, {
        username : req.body.username,
        contact : req.body.contact,
        password : req.body.password
    }, {new : true})
        .then(user => {
            if(!user) {
                return res.status(404).send({
                    message : "User not found with this id !"
                });
            }

            console.log("User successfully updated !");
            res.send(user);
        })
        .catch(err => {
            if(err.kind === 'ObjectId'){
                return res.status(404).send({
                    message : "User not found with this id !"
                });
            }

            res.status(500).send({
                message : err.message || "Some error occurred while updating the User !"
            });
        })
};

// Delete a user with the specified userId in the request
exports.delete = (req, res) => {
    User.findByIdAndRemove(req.params.userid)
        .then(user => {
            if(!user) {
                return res.status(404).send({
                    message : "User not found with this id !"
                });
            }

            console.log("User successfully deleted !");
            res.send({
                message : "User successfully deleted !"
            });
        })
        .catch(err => {
            if(err.kind === 'ObjectId' || err.name === 'NotFound'){
                return res.status(404).send({
                    message : "User not found with this id !"
                })
            }

            res.status(500).send({
                message : "Could not delete the User with this id !"
            });     
        })
};
