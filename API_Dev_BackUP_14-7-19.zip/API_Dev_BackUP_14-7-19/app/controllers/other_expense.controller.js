const Expense = require('../../models/other_expense.model')

// Create and Save a new Expense
exports.create = (req, res) => {

    // Create an Expense
    const expense = new Expense({
        name : req.body.name,
        details : req.body.details,
        amount : req.body.amount,
        date : req.body.date
    })

    //Save Expense in DB
    expense.save()
        .then( data => {
            console.log("Expense successfully saved !");
            res.send(data);
        })
        .catch(err => {
            res.status(500).send({
                message : err.message || "Some error occurred while creating the Expense"
            })
        });
};


// Retrieve and return all Expenses from the database.
exports.findAll = (req, res) => {
    Expense.find().sort({date : -1})
        .then( expenses => {
            console.log("Expenses successfully retrieved !");
            res.send(expenses);
        })
        .catch(err => {
            res.status(500).send({
                message : err.message || "Some error occurred while retrieving Expenses"
            })            
        });
};

// Retrieve All Expenses using date
exports.findAllByDate = (req, res) => {
    Expense.find().select({'date' :  req.params.date})
        .then( expenses => {
            console.log("Expenses successfully retrieved !");
            res.send(expenses);
        })
        .catch(err => {
            res.status(500).send({
                message : err.message || "Some error occurred while retrieving Expenses"
            })            
        });
}


// Find a single expense with a expenseId
exports.findOne = (req, res) => {

    Expense.findById(req.params.expenseId)
        .then( expense => {
            if(!expense)
            {
                return res.status(404).send({
                    message : "Expense not found !"
                })
            }

            console.log("Expense with id successfully retrieved !");
            res.send(expense);
        })
        .catch(err => {
            if(err.kind === 'ObjectId'){
                return res.status(404).send({
                    message : "Expense not found !"
                });
            }
            
            return res.status(500).send({
                message : err.message || "Some error occured while retrieving expense with id"
            });
            
        });
};


// Update an expense identified by the expenseId in the request
exports.update = (req, res) => {

    //find user and update it with the request body
    Expense.findByIdAndUpdate( req.params.expenseId, {
        name : req.body.name,
        details : req.body.details,
        amount : req.body.amount,
        date : req.body.date
    }, {new : true})
        .then(expense => {
            if(!expense) {
                return res.status(404).send({
                    message : "Expense not found with this id !"
                });
            }

            console.log("Expense successfully updated !");
            res.send(expense);
        })
        .catch(err => {
            if(err.kind === 'ObjectId'){
                return res.status(404).send({
                    message : "Expense not found with this id !"
                });
            }

            res.status(500).send({
                message : err.message || "Some error occurred while updating the expense !"
            });
        })
};


// Delete an expense with the specified expenseId in the request
exports.delete = (req, res) => {
    Expense.findByIdAndRemove(req.params.expenseId)
        .then(expense => {
            if(!expense) {
                return res.status(404).send({
                    message : "Expense not found with this id !"
                });
            }

            console.log("Expense successfully deleted !");
            res.send({
                message : "Expense successfully deleted !"
            });
        })
        .catch(err => {
            if(err.kind === 'ObjectId' || err.name === 'NotFound'){
                return res.status(404).send({
                    message : "Expense not found with this id !"
                })
            }

            res.status(500).send({
                message : "Could not delete the expense with this id !"
            });     
        })
};

