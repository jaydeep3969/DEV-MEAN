import { BillAutomobiles } from './bill-automobiles';

describe('BillAutomobiles', () => {
  it('should create an instance', () => {
    expect(new BillAutomobiles()).toBeTruthy();
  });
});
