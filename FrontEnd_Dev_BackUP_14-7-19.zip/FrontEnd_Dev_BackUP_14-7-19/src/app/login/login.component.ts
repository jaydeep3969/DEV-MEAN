import { Component, OnInit } from '@angular/core';
import { UserManagementService } from 'src/services/user-management.service';
import { User } from 'src/models/user';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user : User = new User();
  constructor(private userManagementService : UserManagementService) { }

  ngOnInit() {
  }

  signIn(){
    console.log("In SignIn");
    this.userManagementService.verifyUser(this.user)
      .subscribe(msg => {
        if(msg.message == 1)
          console.log("Success");
        else if(msg.message == -1)
          console.log("Failure");
      })
  }

}
