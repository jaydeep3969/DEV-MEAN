const Electronic = require('../../../models/items/electronics.model')

// Create and Save a new user
exports.create = (req, res) => {

    // Create a electronic
    const electronic = new Electronic({
        name : req.body.name,
        quantity : req.body.quantity,
        pp : req.body.pp,
        sp : req.body.sp
    })

    //Save Electronic in DB
    electronic.save()
        .then( data => {
            console.log("Electronic successfully saved !");
            res.send(data);
        })
        .catch(err => {
            res.status(500).send({
                message : err.message || "Some error occurred while creating the electronic-item"
            })
        });
};



// Retrieve and return all users from the database.
exports.findAll = (req, res) => {
    Electronic.find()
        .then( electronics => {
            console.log("Electronices successfully retrieved !");
            res.send(electronics);
        })
        .catch(err => {
            res.status(500).send({
                message : err.message || "Some error occurred while retrieving electronics"
            })            
        });
};



// Find a single user with a userId
exports.findOne = (req, res) => {

    Electronic.findById(req.params.electronicId)
        .then( electronic => {
            if(!electronic)
            {
                return res.status(404).send({
                    message : "Electronic not found !"
                })
            }

            console.log("Electronic with id successfully retrieved !");
            res.send(electronic);
        })
        .catch(err => {
            if(err.kind === 'ObjectId'){
                return res.status(404).send({
                    message : "Electronic not found !"
                });
            }
            
            return res.status(500).send({
                message : err.message || "Some error occured while retrieving electronic with id"
            });
            
        });
};



// Update a user identified by the userId in the request
exports.update = (req, res) => {

    //find user and update it with the request body
    Electronic.findByIdAndUpdate( req.params.electronicId, {
        sr_no : req.body.sr_no,
        name : req.body.name,
        quantity : req.body.quantity,
        pp : req.body.pp,
        sp : req.body.sp
    }, {new : true})
        .then(electronic => {
            if(!electronic) {
                return res.status(404).send({
                    message : "Electronic not found with this id !"
                });
            }

            console.log("Electronic successfully updated !");
            res.send(electronic);
        })
        .catch(err => {
            if(err.kind === 'ObjectId'){
                return res.status(404).send({
                    message : "Electronic not found with this id !"
                });
            }

            res.status(500).send({
                message : err.message || "Some error occurred while updating the electronic !"
            });
        })
};



// Delete a user with the specified userId in the request
exports.delete = (req, res) => {
    Electronic.findByIdAndRemove(req.params.electronicId)
        .then(electronic => {
            if(!electronic) {
                return res.status(404).send({
                    message : "Electronic not found with this id !"
                });
            }

            console.log("Electronic successfully deleted !");
            res.send({
                message : "Electronic successfully deleted !"
            });
        })
        .catch(err => {
            if(err.kind === 'ObjectId' || err.name === 'NotFound'){
                return res.status(404).send({
                    message : "Electronic not found with this id !"
                })
            }

            res.status(500).send({
                message : "Could not delete the electronic with this id !"
            });     
        })
};


//Find One Electronics by Name
exports.findOneByName = (req, res) => {
    Electronic.findOne({ 'name' : req.params.electronicName })
        .then( electronic => {
            if(!electronic)
            {
                return res.status(404).send({
                    message : "Electronic not found !"
                })
            }

            console.log("Electronic with name successfully retrieved !");
            res.send(electronic);
        })
        .catch(err => {
            if(err.kind === 'ObjectId'){
                return res.status(404).send({
                    message : "Electronic not found !"
                });
            }
            
            return res.status(500).send({
                message : err.message || "Some error occured while retrieving electronic with name"
            });
            
        });
};